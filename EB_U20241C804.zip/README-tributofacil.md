# LP-EB-4797 - geraldine suarez chinga

## Sobre el proyecto

Esta es la Landing Page del caso Tributo Fácil, una plataforma pensada para que las personas, los emprendedores, las empresas y los contadores puedan consultar, declarar y pagar sus obligaciones tributarias sin tener que revisar distintos canales. La idea central del sitio es que cada tipo de usuario tenga su propio espacio: desde la página de inicio se puede elegir el perfil que corresponde, y ese clic lleva a una página completa pensada específicamente para esa persona.

Por eso el proyecto no es una sola página larga, sino cinco páginas conectadas entre sí:

- `index.html` — la portada, con la presentación general y el formulario de contacto.
- `personas-naturales.html` — pensada para quien quiere consultar sus pagos, deudas y recibos por honorarios.
- `emprendedores.html` — orientación para emitir comprobantes electrónicos y declarar por primera vez.
- `empresas.html` — gestión de declaraciones, reportes y comprobantes de forma centralizada.
- `contadores.html` — preguntas frecuentes agrupadas por tema y canales de atención, para resolver dudas rápido.

Cada una de estas páginas corresponde directamente a una Historia de Usuario (HU01 a HU04) desarrollada en la Pregunta 1, y cada sección dentro de ellas responde a un criterio de aceptación puntual, para que quede clara la trazabilidad entre lo que se pidió y lo que se construyó.

## Tecnologías utilizadas

HTML, CSS y JavaScript, todo puro y sin frameworks (nada de Bootstrap ni jQuery, como pedía el enunciado). El JavaScript se usa para dos cosas: el menú del celular (mostrar y ocultar la navegación) y la validación del formulario de contacto, que revisa que los campos obligatorios estén completos, que el correo tenga un formato válido y que se haya aceptado los términos, mostrando un mensaje claro en cada caso.

## Por qué se eligió este diseño

Se buscó una paleta que se sintiera formal y de confianza, porque el usuario le va a confiar información sobre su situación tributaria. Por eso el color principal es un verde azulado oscuro, en vez del azul genérico que se usa en casi cualquier plataforma de compras. Como acento se usó un dorado suave, pensado para asociarse con el tema del dinero y los valores, sin que se sienta recargado.

Para la tipografía se combinó una fuente serif en los títulos (transmite más formalidad, algo normalito en un servicio tributario) con una fuente sans-serif del sistema en el texto normal, que es más cómoda de leer en pantalla. No se usaron fuentes externas a propósito, para que el proyecto funcione igual de bien sin conexión a internet.

El elemento que se repite en todo el sitio y le da identidad son las insignias de estado: Pagado, Pendiente y Vencido. Aparecen en la portada y en la página de personas naturales, y ayudan a que cualquier usuario entienda de un vistazo en qué situación está cada obligación, sin tener que leer un párrafo entero.

## Accesibilidad y estructura

Se usaron etiquetas semánticas (`header`, `main`, `section`, `footer`), un enlace para saltar al contenido principal pensado para quien navega con teclado, atributos `aria-label` y `aria-current` para identificar la sección activa, y se cuidó que los colores de texto y fondo tuvieran buen contraste. Las preguntas frecuentes de la página de contadores se armaron con `<details>` y `<summary>`, que son etiquetas clasicas

## Responsive

El sitio se probó en tres tamaños: computadora, tablet y celular, usando dos puntos de quiebre en el CSS (900px y 560px). En pantallas chicas el menú se convierte en un botón de hamburguesa, las tarjetas pasan de varias columnas a una sola, y los botones y el formulario se ajustan al ancho disponible.


